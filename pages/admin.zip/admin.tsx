import React from "react";
import { FaCar, FaUsers, FaChartBar } from "react-icons/fa";

const AdminDashboard = () => {
  return (
    <div className="dashboard">
      {/* Sidebar */}
      <aside className="sidebar">
        <h2 className="sidebar-title">Admin Dashboard</h2>
        <nav>
          <a href="#stats" className="sidebar-link active">
            <FaChartBar className="icon" /> Statistics
          </a>
          <a href="#manage-listings" className="sidebar-link">
            <FaCar className="icon" /> Manage Listings
          </a>
          <a href="#manage-users" className="sidebar-link">
            <FaUsers className="icon" /> Manage Users
          </a>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="main-content">
        {/* Header */}
        <header className="dashboard-header">
          <h1>Admin Dashboard</h1>
          <p>Welcome back, Admin! Here's the latest overview.</p>
        </header>

        {/* Statistics Section */}
        <section id="stats" className="section">
          <h2>Statistics</h2>
          <div className="stats-grid">
            <div className="stat-card">
              <FaCar className="stat-icon" />
              <h3>Total Listings</h3>
              <p>120</p>
            </div>
            <div className="stat-card">
              <FaUsers className="stat-icon" />
              <h3>Total Users</h3>
              <p>50</p>
            </div>
          </div>
        </section>

        {/* Manage Listings Section */}
        <section id="manage-listings" className="section">
          <h2>Manage Listings</h2>
          <p>View, edit, or delete vehicle listings here.</p>
          {/* Listings grid */}
          <div className="listings-grid">
            <div className="card">
              <h3>Honda Civic</h3>
              <p>Price: €15,000</p>
              <button>Edit</button>
              <button>Delete</button>
            </div>
            {/* Add more listings dynamically */}
          </div>
        </section>

        {/* Manage Users Section */}
        <section id="manage-users" className="section">
          <h2>Manage Users</h2>
          <p>View and manage user profiles.</p>
          {/* Users grid */}
          <div className="users-grid">
            <div className="card">
              <h3>John Doe</h3>
              <p>Email: john.doe@example.com</p>
              <button>Edit</button>
              <button>Delete</button>
            </div>
            {/* Add more users dynamically */}
          </div>
        </section>
      </main>
    </div>
  );
};

export default AdminDashboard;
