import { useRouter } from "next/router";
import React from "react";

const sampleListings = [
  {
    id: 1,
    title: "Honda Civic",
    price: "15000",
    brandLogo: "https://www.carlogos.org/car-logos/honda-logo.png",
    dateAdded: "2024-01-01",
    engineType: "Petrol",
  },
  {
    id: 2,
    title: "Yamaha R1",
    price: "12000",
    brandLogo: "https://www.carlogos.org/car-logos/yamaha-logo.png",
    dateAdded: "2024-02-10",
    engineType: "Petrol",
  },
];

const ListingDetail = () => {
  const router = useRouter();
  const { id } = router.query;

  const listing = sampleListings.find((item) => item.id === Number(id));

  if (!listing) {
    return <p className="text-center text-gray-500">Listing not found.</p>;
  }

  return (
    <div className="max-w-2xl mx-auto mt-10 p-6 bg-white shadow-md rounded-lg">
      <div className="flex items-center mb-6">
        <img
          src={listing.brandLogo}
          alt={listing.title}
          className="w-16 h-16 object-contain mr-4"
        />
        <h1 className="text-3xl font-bold text-gray-800">{listing.title}</h1>
      </div>
      <p className="text-gray-700 text-lg font-medium mb-2">Price: ${listing.price}</p>
      <p className="text-gray-600 text-md mb-2">Engine Type: {listing.engineType}</p>
      <p className="text-gray-500 text-sm">Date Added: {listing.dateAdded}</p>
    </div>
  );
};

export default ListingDetail;
