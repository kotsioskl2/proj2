import React, { useState } from "react";

const AddListing: React.FC = () => {
  const [title, setTitle] = useState("");
  const [price, setPrice] = useState("");
  const [brandLogo, setBrandLogo] = useState("");
  const [engineType, setEngineType] = useState("Petrol");
  const [dateAdded, setDateAdded] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log({ title, price, brandLogo, engineType, dateAdded });
    alert("Listing added successfully!");
  };

  return (
    <div className="flex justify-center items-center min-h-screen">
      <div className="card max-w-lg w-full p-8">
        <h1 className="text-3xl font-bold mb-6 text-center text-white">Post a Listing</h1>
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="block text-white font-medium mb-2">Title</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter the title (e.g., Honda Civic)"
              className="w-full p-3 text-gray-800"
              required
            />
          </div>
          <div className="mb-4">
            <label className="block text-white font-medium mb-2">Price ($)</label>
            <input
              type="number"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="Enter the price"
              className="w-full p-3 text-gray-800"
              required
            />
          </div>
          <div className="mb-4">
            <label className="block text-white font-medium mb-2">Brand Logo URL</label>
            <input
              type="url"
              value={brandLogo}
              onChange={(e) => setBrandLogo(e.target.value)}
              placeholder="Enter the logo URL"
              className="w-full p-3 text-gray-800"
            />
          </div>
          <div className="mb-4">
            <label className="block text-white font-medium mb-2">Engine Type</label>
            <select
              value={engineType}
              onChange={(e) => setEngineType(e.target.value)}
              className="w-full p-3 text-gray-800"
            >
              <option value="Petrol">Petrol</option>
              <option value="Diesel">Diesel</option>
              <option value="Electric">Electric</option>
            </select>
          </div>
          <div className="mb-4">
            <label className="block text-white font-medium mb-2">Date Added</label>
            <input
              type="date"
              value={dateAdded}
              onChange={(e) => setDateAdded(e.target.value)}
              className="w-full p-3 text-gray-800"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full bg-blue-500 py-3 text-white font-bold rounded-lg hover:bg-blue-600 transition"
          >
            Post Listing
          </button>
        </form>
      </div>
    </div>
  );
};

export default AddListing;
