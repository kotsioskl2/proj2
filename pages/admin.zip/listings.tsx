import React from "react";

interface ListingCardProps {
  listing: {
    title: string;
    price: string;
    engineType: string;
    engineSize: string;
    fuelType: string;
    dateAdded: string;
    image: string;
  };
}

const ListingCard: React.FC<ListingCardProps> = ({ listing }) => {
  return (
    <div className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <img
        src={listing.image || "/placeholder-image.png"}
        alt={listing.title}
        className="h-40 w-full object-cover"
      />
      <div className="p-4">
        <h3 className="text-lg font-bold">{listing.title}</h3>
        <p className="text-gray-700">Price: {listing.price}</p>
        <p className="text-gray-700">Engine: {listing.engineType}</p>
        <p className="text-gray-700">Engine Size: {listing.engineSize}</p>
        <p className="text-gray-700">Fuel Type: {listing.fuelType}</p>
        <p className="text-gray-700">Added: {listing.dateAdded}</p>
      </div>
    </div>
  );
};

export default ListingCard;
