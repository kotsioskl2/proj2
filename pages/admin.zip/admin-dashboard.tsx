import React, { useState } from "react";
import Sidebar from "../components/Sidebar";

const AdminDashboard: React.FC = () => {
  const [listings, setListings] = useState([
    { id: 1, title: "Honda Civic", price: "$15000" },
    { id: 2, title: "Yamaha R1", price: "$12000" },
    { id: 3, title: "Tesla Model 3", price: "$35000" },
  ]);

  const handleDelete = (id: number) => {
    const updatedListings = listings.filter((listing) => listing.id !== id);
    setListings(updatedListings);
  };

  return (
    <div className="flex">
      <Sidebar />
      <div className="flex-grow p-6">
        <h1 className="text-3xl font-bold text-center mb-6">Admin Dashboard</h1>
        <div className="bg-white shadow rounded-lg p-6">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-gray-200">
                <th className="text-left p-3 border-b">Title</th>
                <th className="text-left p-3 border-b">Price</th>
                <th className="text-left p-3 border-b">Actions</th>
              </tr>
            </thead>
            <tbody>
              {listings.map((listing) => (
                <tr key={listing.id}>
                  <td className="p-3 border-b">{listing.title}</td>
                  <td className="p-3 border-b">{listing.price}</td>
                  <td className="p-3 border-b">
                    <button
                      onClick={() => handleDelete(listing.id)}
                      className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
