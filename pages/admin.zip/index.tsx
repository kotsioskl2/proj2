import React, { useState } from "react";

const listings = [
  {
    name: "Honda Civic",
    price: "€15000",
    engine: "Petrol",
    mileage: 50000,
    transmission: "Manual",
    color: "Red",
    year: 2020,
  },
  {
    name: "Yamaha R1",
    price: "€12000",
    engine: "Petrol",
    mileage: 20000,
    transmission: "Automatic",
    color: "Blue",
    year: 2022,
  },
  // Add more listings here...
];

const Home = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterEngine, setFilterEngine] = useState("All");
  const [filterYear, setFilterYear] = useState("All");

  const filteredListings = listings.filter((listing) => {
    return (
      (searchTerm === "" ||
        listing.name.toLowerCase().includes(searchTerm.toLowerCase())) &&
      (filterEngine === "All" || listing.engine === filterEngine) &&
      (filterYear === "All" || listing.year === parseInt(filterYear))
    );
  });

  return (
    <div>
      {/* Navigation Bar */}
      <nav className="nav-bar">
        <div className="nav-logo">Headers Emulation</div>
        <div className="nav-links">
          <a href="/" className="nav-button">
            Home
          </a>
          <a href="/admin" className="nav-button">
            Admin Dashboard
          </a>
        </div>
      </nav>

      <header>
        <h1>Welcome to Headers Emulation 🚗</h1>
        <p>Find or post your perfect vehicle!</p>
      </header>

      <div className="filters">
        <input
          type="text"
          placeholder="Search listings..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <select
          value={filterEngine}
          onChange={(e) => setFilterEngine(e.target.value)}
        >
          <option value="All">All Engines</option>
          <option value="Petrol">Petrol</option>
          <option value="Diesel">Diesel</option>
          <option value="Electric">Electric</option>
        </select>
        <select
          value={filterYear}
          onChange={(e) => setFilterYear(e.target.value)}
        >
          <option value="All">All Years</option>
          <option value="2020">2020</option>
          <option value="2021">2021</option>
          <option value="2022">2022</option>
        </select>
      </div>

      <div className="grid">
        {filteredListings.map((listing, index) => (
          <div key={index} className="card">
            <div className="content">
              <h3>{listing.name}</h3>
              <p>Price: {listing.price}</p>
              <p>Engine: {listing.engine}</p>
              <p>Mileage: {listing.mileage}</p>
              <p>Transmission: {listing.transmission}</p>
              <p>Color: {listing.color}</p>
              <p>Year: {listing.year}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Home;
