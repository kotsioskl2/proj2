const getCurrentUser = async () => {
  // Simulate fetching user data
  return {
    email: 'admin@example.com',
    role: 'admin',
  };
};

export default getCurrentUser;
