import React from "react";

const Users: React.FC = () => {
  return (
    <div>
      <h1 className="text-4xl font-bold text-gray-800 mb-8 text-center">Manage Users</h1>
      <p className="text-gray-600 text-center">This page is for managing users.</p>
    </div>
  );
};

export default Users;
