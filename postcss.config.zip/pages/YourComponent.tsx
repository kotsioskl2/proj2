import React, { FC } from 'react';

const YourComponent: FC = () => {
    return (
        <div>
            {/* Your component content */}
        </div>
    );
};

export default YourComponent;
